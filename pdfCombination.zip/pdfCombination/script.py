import os
from PyPDF2 import PdfReader, PdfWriter

# ▼ スクリプトが存在するフォルダのパスを取得（実行環境に依存しない）
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# スクリプトと同じ場所にある「pdfCombination」フォルダを指定
INPUT_DIR = os.path.join(BASE_DIR, "pdfCombination")
# スクリプトと同じ場所に結合後ファイルを出力
OUTPUT_FILE = os.path.join(BASE_DIR, "merged_all_pages.pdf")

def merge_all_pages(input_dir, output_file):
    # 読み込み先フォルダが存在しない場合のチェック
    if not os.path.exists(input_dir):
        print(f"エラー: 入力フォルダが見つかりません → {input_dir}")
        return

    writer = PdfWriter()

    # フォルダ内のPDFを取得（ファイル名順）
    pdf_files = sorted([f for f in os.listdir(input_dir) if f.lower().endswith(".pdf")])

    if not pdf_files:
        print("PDFが見つかりませんでした")
        return

    for pdf in pdf_files:
        path = os.path.join(input_dir, pdf)
        try:
            reader = PdfReader(path)
            for page in reader.pages:
                writer.add_page(page)
            print(f"OK: {pdf} （全{len(reader.pages)}ページ）を追加")
        except Exception as e:
            print(f"ERROR: {pdf} の処理に失敗 → {e}")

    # 出力
    with open(output_file, "wb") as f:
        writer.write(f)

    print(f"\n完了！ → {output_file}")

if __name__ == "__main__":
    merge_all_pages(INPUT_DIR, OUTPUT_FILE)